from collections import defaultdict

import pandas as pd


def loadDictionary():
    # 先读取情感极性词典，自己调整路径
    # 读取否定词文件
    not_word_file = open('否定词.txt', 'r+', encoding='utf-8')
    not_word_list = not_word_file.readlines()
    not_word_list = [w.strip() for w in not_word_list]

    # 读取情感词典
    df = pd.read_excel(r"D:\DataScience\pos2.0.xlsx")
    sen_key = df['词汇'].values.tolist()
    sen_score = df['权重'].values.tolist()
    sen_dict = {}
    for i in range(len(sen_key)):
        sen_dict[sen_key[i]] = sen_score[i]

    # 读取程度副词文件,格式为副词+逗号+权重值
    df = pd.read_excel(r"D:\Code\Python\DataScience\count\degree.xlsx")
    deg_key = df['内容'].values.tolist()
    deg_score = df['权值'].values.tolist()
    degree_dict = {}
    for i in range(len(deg_key)):
        degree_dict[deg_key[i]] = deg_score[i]
    # degree_file = open('程度副词.txt', 'r+', encoding='utf-8')
    # degree_list = degree_file.readlines()
    # degree_list = [w.strip("\t") for w in degree_list]
    # degree_dict = defaultdict()
    # for i in degree_list:
    #     degree_dict[i.split(",")[0]] = i.split(",")[1]
    # 关闭打开的文件
    not_word_file.close()
    # degree_file.close()
    return not_word_list, sen_dict, degree_dict


# 找出文本中的情感词、否定词和程度副词
def classify_words(not_word_list, sen_dict, degree_dict, words):
    sen_word = dict()
    not_word = dict()
    degree_word = dict()
    # # 分类
    # for i in words:
    #     if i in sen_dict.keys() and i not in not_word_list and i not in degree_dict.keys():
    #          # 找出分词结果中在情感字典中的词
    #         sen_word[i] = sen_dict[i]
    #      elif i in not_word_list and i not in degree_dict.keys():
    #           # 分词结果中在否定词列表中的词
    #           not_word[i] = -1.0
    #      elif i in degree_dict.keys():
    #          # 分词结果中在程度副词中的词
    #             degree_word[i] = degree_dict[i]
    for i in range(len(words)):
        word = words[i]
        if word in sen_dict.keys() and word not in not_word_list and word not in degree_dict.keys():
            # 找出分词结果中在情感字典中的词
            sen_word[i] = sen_dict[word]
        elif word in not_word_list and word not in degree_dict.keys():
            # 分词结果中在否定词列表中的词
            not_word[i] = -1.0
        elif word in degree_dict.keys():
            # 分词结果中在程度副词中的词
            degree_word[i] = degree_dict[word]

    # 返回分类结果
    return sen_word, not_word, degree_word


def calculateScore(words, sen_word, not_word, degree_word):
    # 情感词下标初始化
    sentiment_index = -1
    # 情感词的位置下标集合
    sentiment_index_list = list(sen_word.keys())
    score = 0
    weight = 1.0
    for i in range(0, len(words)):
        # 如果是情感词
        if i in sen_word.keys():
            # 权重*情感词得分
            score += weight * float(sen_word[i])
            # 情感词下标加一，获取下一个情感词的位置
            sentiment_index += 1
            weight = 1.0
            if sentiment_index < len(sentiment_index_list) - 1:
                # 判断当前的情感词与下一个情感词之间是否有程度副词或否定词
                for j in range(sentiment_index_list[sentiment_index], sentiment_index_list[sentiment_index + 1]):
                    # 更新权重，如果有否定词，权重取反
                    if j in not_word.keys():
                        weight *= -1
                    elif j in degree_word.keys():
                        weight *= float(degree_word[j])
        # 定位到下一个情感词
        if sentiment_index < len(sentiment_index_list) - 1:
            i = sentiment_index_list[sentiment_index + 1]
    return score


def get_scores(not_word_list, sen_dict, degree_dict, word_list):
    final_sum = []
    # 遍历分词结果
    for words in word_list:
        sen_word, not_word, degree_word = classify_words(not_word_list, sen_dict, degree_dict, words)
        final_sum.append(calculateScore(words, sen_word, not_word, degree_word))
    return final_sum


def sentiment_analyze(in_file, out_file):
    # 加载心态词典
    not_word_list, sen_dict, degree_dict = loadDictionary()
    xlsx = pd.read_excel(in_file)
    separate_list = xlsx['分词']
    word_list = []
    for c in separate_list:
        c = str(c)
        word_list.append(c.split('/'))
    sum_score = get_scores(not_word_list, sen_dict, degree_dict, word_list)
    xlsx.insert(len(xlsx.columns), '情感得分', sum_score)
    xlsx.to_excel(out_file)
    print('Generated ' + out_file)


sentiment_analyze(r'D:\DataScience\final\separate.xlsx', r'D:\DataScience\final\yzqsentiment.xlsx')