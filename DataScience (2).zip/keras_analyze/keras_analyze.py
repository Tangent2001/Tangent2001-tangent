from __future__ import absolute_import  # 导入3.x的特征函数
from __future__ import print_function

import pandas as pd
import numpy as np
import jieba
from separate_words.separate import get_comment_separate
from keras.preprocessing import sequence
from keras.optimizers import SGD, RMSprop, Adagrad
from keras.utils import np_utils
from keras.models import Sequential
from keras.layers.core import Dense, Dropout, Activation
from keras.layers.embeddings import Embedding
from keras.layers.recurrent import LSTM, GRU
from keras.models import load_model


def analyze():
    neg = pd.read_excel(r"D:\DataScience\keras\neg.xlsx")
    pos = pd.read_excel(r"D:\DataScience\keras\pos.xlsx")
    pos['mark'] = 1
    neg['mark'] = 0
    pn = pd.concat([pos, neg], ignore_index=True)  # 合并语料
    neglen = len(neg)
    poslen = len(pos)
    pn.insert(len(pn.columns), '分词', get_comment_separate(pn['评论内容']))

    comment = pd.read_excel(r'D:\DataScience\final\all_comment.xlsx')  # 读入评论内容
    comment.insert(len(comment.columns), '分词', get_comment_separate(comment['评论内容']))
    d2v_train = pd.concat([pn['分词'], comment['分词']], ignore_index=True)

    w = []
    for i in d2v_train:
        w.extend(i)

    dict = pd.DataFrame(pd.Series(w).value_counts())  # 统计词的出现次数
    del w, d2v_train
    dict['id'] = list(range(1, len(dict) + 1))
    word2ind = dict['id'].to_dict()
    pn.insert(len(pn.columns), 'sent', [[word2ind[i] for i in it] for it in pn['分词']])

    maxlen = 50

    print("Pad sequences (samples x time)")
    pn['sent'] = list(sequence.pad_sequences(pn['sent'], maxlen=maxlen))

    x = np.array(list(pn['sent']))[::2]  # 训练集
    y = np.array(list(pn['mark']))[::2]
    xt = np.array(list(pn['sent']))[1::2]  # 测试集
    yt = np.array(list(pn['mark']))[1::2]
    xa = np.array(list(pn['sent']))  # 全集
    ya = np.array(list(pn['mark']))
    #
    # print('Build model...')
    # model = Sequential()
    # model.add(Embedding(len(dict) + 1, 256))
    # model.add(LSTM(128))  # try using a GRU instead, for fun
    # model.add(Dropout(0.5))
    # model.add(Dense(1))
    # model.add(Activation('sigmoid'))
    #
    # model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
    #
    # model.fit(xa, ya, batch_size=16, epochs=3)  # 训练时间为若干个小时
    #
    # print("Saving model to disk \n")
    # mp = r"D:\DataScience\keras\iris_model.h5"
    # model.save(mp)

    print("Using loaded model to predict...")
    model = load_model(r"D:\DataScience\keras\iris_model.h5")

    num = model.predict(xa, batch_size=10)
    df = pd.DataFrame(num)
    df.insert(len(df.columns),'sent',pn['评论内容'])
    df.to_excel(r'D:\DataScience\keras\samples.xlsx')
    print('Generated ')

    comment.insert(len(pn.columns), 'sent', [[word2ind[i] for i in it] for it in comment['分词']])
    maxlen = 50
    print("Pad sequences (samples x time)")
    comment['sent'] = list(sequence.pad_sequences(comment['sent'], maxlen=maxlen))
    xa = np.array(list(comment['sent']))
    num = model.predict(xa, batch_size=10)
    df = pd.DataFrame(num)
    comment.insert(len(df.columns),'情感得分',df)
    comment.to_excel(r'D:\DataScience\final\kerassentiment.xlsx')
    print('Generated ')
