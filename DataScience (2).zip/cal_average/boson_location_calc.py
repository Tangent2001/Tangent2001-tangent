import pandas as pd


def boson_location_calc(in_file):
    xlsx = pd.read_excel(in_file)
    location = xlsx['省份或国家']
    location_list = [line.strip() for line in open(r'D:\DataScience\province.txt', 'r', encoding='utf-8').readlines()]
    location_dict={}
    location_count = {}
    for d in location_list:
        location_dict[d]=0
        location_count[d] = 0
    for row in xlsx.itertuples():
        if getattr(row, '省份或国家') in location_dict:
            location_dict[getattr(row, '省份或国家')] += getattr(row, '情感得分')
            location_count[getattr(row, '省份或国家')] += 1
    final_data = {}
    for d in location_dict:
        if location_count[d] != 0:
            final_data[d] = location_dict[d]
    df = pd.Series(final_data)
    df.to_excel(r'D:\DataScience\boson\loc_calc.xlsx')


boson_location_calc(r'D:\DataScience\boson\sentiment.xlsx')