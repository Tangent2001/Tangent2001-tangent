import math

from get_data.date_generator import date_list
import pandas as pd


def boson_calc(in_file, step):
    dates = date_list('20200103', '20201230')
    xlsx = pd.read_excel(in_file)
    time = xlsx['发布时间']
    date = []
    for i in time:
        date.append(i[5:7] + i[8:10])
    xlsx.insert(len(xlsx.columns), 'date', date)
    date_dict = {}
    date_count = {}
    for d in dates:
        date_dict[d] = 0
        date_count[d] = 0
    for row in xlsx.itertuples():
        if getattr(row, '乘点赞数') > 0:
            date_dict[getattr(row, 'date')] += getattr(row, '乘点赞数')
        date_count[getattr(row, 'date')] += abs(getattr(row, '乘点赞数'))
    final_data = {}
    count = 0
    current_scores = 0
    current_count = 0
    startDate = ''
    for d in date_dict:
        if d in ['0122','0127','0201','0204','0207','0210','0213','0216','0220','0225','0301,''0315','0401','0415','0501','0515','0601','0615','0630']:
            if current_count != 0:
                final_data[startDate + '-' + d] = current_scores / current_count
            count = 0
            current_scores = 0
            current_count = 0
        if count == 0:
            startDate = d
        current_scores += date_dict[d]
        current_count += date_count[d]
        count += 1
    df = pd.Series(final_data)
    df.to_excel(r'D:\DataScience\snow\calc.xlsx')


boson_calc(r'D:\DataScience\predict\complete.xlsx', 7)
