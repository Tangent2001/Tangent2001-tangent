import pandas as pd


# 基于波森情感词典计算情感值
def get_scores(word_list):
    df = pd.read_table(r"D:\DataScience\Boson.txt", sep=" ", names=['key', 'score'])
    key = df['key'].values.tolist()
    score = df['score'].values.tolist()
    final_sum = []
    for words in word_list:
        score_list = [score[key.index(x)] for x in words if (x in key)]
        final_sum.append(sum(score_list))
    return final_sum

# 基于自定义字典
# def get_scores(word_list):
#     df = pd.read_excel(r"D:\DataScience\dict1.xlsx")
#     key = df['内容'].values.tolist()
#     score = df['权值'].values.tolist()
#     final_sum = []
#     for words in word_list:
#         score_list = [score[key.index(x)] for x in words if (x in key)]
#         if len(score_list) == 0:
#             final_sum.append(0)
#         else:
#             final_sum.append(sum(score_list)/len(score_list))
#     return final_sum


def sentiment_analyze(in_file,out_file):
    xlsx = pd.read_excel(in_file)
    separate_list = xlsx['分词']
    word_list = []
    for c in separate_list:
        c = str(c)
        word_list.append(c.split('/'))
    sum_score = get_scores(word_list)
    xlsx.insert(len(xlsx.columns), '情感得分', sum_score)
    xlsx.to_excel(out_file)
    print('Generated '+out_file)



