import jieba
import re
import pandas as pd

import emoji


def separate(in_file,out_file):
    xlsx = pd.read_excel(in_file)
    comments = xlsx['评论内容']
    words = get_comment_separate(comments)
    xlsx.insert(len(xlsx.columns), '分词', words)
    emojis = get_emoji(comments)
    xlsx.insert(len(xlsx.columns), 'emoji', emojis)
    # 要提前创建好文件夹
    xlsx.to_excel(out_file)
    print('Generated '+out_file)


def extract_emojis(s):
    pattern = re.compile(u"\[[0-9a-zA-Z\u4e00-\u9fa5]\]")
    emojis = re.findall(pattern, s)
    for c in s:
        if c in emoji.UNICODE_EMOJI:
            emojis.append(c)
    return emojis


def get_comment_separate(comments):
    jieba.load_userdict('D:\\DataScience\\words.txt')
    stopWords = [line.strip() for line in open('D:\\DataScience\\stop.txt', 'r', encoding='utf-8').readlines()]
    words = []
    for s in comments:
        s = str(s)
        seg_list = jieba.cut(s, HMM=True)
        res=[]
        for w in seg_list:
            if w not in stopWords and not w.isspace():
                res.append(w)
        words.append('/'.join(res))
    return words


def get_emoji(comments):
    emojis = []
    for s in comments:
        s = str(s)
        seg_list = extract_emojis(s)
        emojis.append('/'.join(seg_list))
    return emojis
