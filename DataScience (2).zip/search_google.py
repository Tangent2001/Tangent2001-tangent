import requests
import pandas as pd
import re
from bs4 import BeautifulSoup
from get_data.get_comments import get_one_news_comments


def get_prev_news():
    USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Safari/537.36"
    headers = {'user_agent': USER_AGENT}
    all_comments = []
    for i in range(0, 10, 10):
        URL = "https://www.google.com/search?q=肺炎+site:news.163.com&lr=&hl=zh-CN&as_qdr=all&tbs=cdr:1,cd_min:12/31/2019,cd_max:1/19/2020&sxsrf=ALeKk02OZsQtJuskjdjBLSjY-jqiTrliEQ:1611157694072&ei=vlAIYKjvA8TO0PEP9aSh-AI&start=0&sa=N&ved=2ahUKEwioxqCQ7qruAhVEJzQIHXVSCC84ChDy0wN6BAgGEDs&biw=1062&bih=969"
        resp = requests.get(URL,headers)
        if resp.status_code == 200:
            soup = BeautifulSoup(resp.content, "html.parser")
        else:
            continue
        results = []
        a=soup.find_all('div', attrs={'class': 'ZINbbc xpd O9g5cc uUPGi'})
        for g in soup.find_all('div', attrs={'class': 'ZINbbc xpd O9g5cc uUPGi'}):
            anchors = g.find_all('a')
            if anchors:
                link = anchors[0]['href']
                link = re.findall('https.*html', link)
                if link is not None:
                    results.extend(link)
        for l in results:
            comments = get_one_news_comments(l)
            if comments is not None:
                all_comments.extend(comments)
    dataFrame = pd.DataFrame(all_comments)
    # 要提前创建好文件夹
    dataFrame.to_excel('D:\\DataScience\\Part5\\prev.xlsx')
    print('Generated D:\\DataScience\\Part5\\prev.xlsx')


get_prev_news()
