import pandas as pd
import jieba


def get(in_file, out_file):
    xlsx = pd.read_excel(in_file)
    location = xlsx['地区']
    time = xlsx['发布时间']
    month = []
    day = []
    region = []
    for i in time:
        month.append(i[5:7])
        day.append(i[8:10])
    for i in location:
        i = str(i)
        word_list = jieba.lcut_for_search(i)
        for j in range(len(word_list)):
            if word_list[j] == '省' or word_list[j] == '市' or word_list[j] == '来自':
                del j
                continue
            if word_list[j].endswith('省') or word_list[j].endswith('市'):
                word_list[j] = word_list[j][:-1]
        if word_list is not None:
            region.append(word_list[0])
    xlsx.insert(len(xlsx.columns), '月份', month)
    xlsx.insert(len(xlsx.columns), '日期', day)
    xlsx.insert(len(xlsx.columns), '省份或国家', region)
    xlsx.to_excel(out_file)
    print('Generated ' + out_file)
