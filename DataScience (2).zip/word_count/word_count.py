import pandas as pd


def word_count(in_file, out_file):
    xlsx = pd.read_excel(in_file)
    separate_list = xlsx['分词']
    word_list = []
    word_dict = {}
    for c in separate_list:
        c = str(c)
        word_list.extend(c.split('/'))
    for w in word_list:
        if w in word_dict:
            word_dict[w] += 1
        else:
            word_dict[w] = 1
    df = pd.Series(word_dict)
    df.to_excel(out_file)
    print('Generated ' + out_file)


def emoji_count(in_file, out_file):
    xlsx = pd.read_excel(in_file)
    separate_list = xlsx['emoji']
    word_list = []
    word_dict = {}
    for c in separate_list:
        c = str(c)
        word_list.extend(c.split('/'))
    for w in word_list:
        if w in word_dict:
            word_dict[w] += 1
        else:
            word_dict[w] = 1
    df = pd.Series(word_dict)
    df.to_excel(out_file)
    print('Generated ' + out_file)