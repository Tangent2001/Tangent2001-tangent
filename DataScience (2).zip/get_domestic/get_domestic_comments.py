import pandas as pd
from separate_words.separate import get_comment_separate


def get_domestic(in_file, out_file):
    xlsx = pd.read_excel(in_file)
    comments = xlsx['评论内容']
    title = xlsx['标题']
    words = get_comment_separate(comments)
    abroad = [line.strip() for line in open('D:\\DataScience\\abroad.txt', 'r', encoding='utf-8').readlines()]
    for w in words:
        for i in w:
            if i in abroad:
                w = []
    xlsx.insert(len(xlsx.columns), 'sepa', words)

