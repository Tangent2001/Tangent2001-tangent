from wordcloud import WordCloud
import numpy as np
from PIL import Image
import jieba
import xlrd
import numpy as np
from matplotlib import pyplot as plt
from matplotlib import colors

# 打开excel
wb = xlrd.open_workbook('phase1.xlsx', encoding_override='utf-8')
# 按工作簿定位工作表
sh = wb.sheet_by_name('Sheet1')
color_list = ['#FFB6C1', '#FFC0CB', '#DC143C', '#FF4500','#D2691E']  # 建立颜色数组
colormap = colors.ListedColormap(color_list)  # 调用
x = sh.col_values(1)
wcd = WordCloud(background_color=None, repeat=False, max_words=300, height=480, width=854, max_font_size=100,
                font_path="msyhl.ttc", colormap=colormap,
                mode="RGBA")
s = ""
for i in range(0, len(x)):
    s += str(x[i])
    s += " "
wcd.generate(s)
wcd.to_image()
wcd.to_file("China_wordcloud5.png")
