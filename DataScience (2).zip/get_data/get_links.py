import requests
import re
from bs4 import BeautifulSoup
from retrying import retry


def correct_news_site_url(date):
    if date == '0122' or 316 < int(date) < 320:
        news_site = 'https://news.163.com/special/daily' + date
    elif date == '0426':
        news_site = 'https://news.163.com/special/daily_26'
    elif date == '0615':
        news_site = 'https://news.163.com/special/daily-' + date
    else:
        news_site = 'https://news.163.com/special/daily_' + date
    return news_site


@retry(stop_max_attempt_number=5, wait_fixed=3000)
def get_news_links(date):
    news_site = requests.get(correct_news_site_url(date), timeout=3)
    news_html = news_site.text
    news_soup = BeautifulSoup(news_html, 'lxml')
    news_soup = news_soup.find('div', attrs={'class': 'section focus'})
    con = news_soup.find('div', attrs={'class': 'con'})
    links = re.findall('https.*html', con.prettify())
    return links
