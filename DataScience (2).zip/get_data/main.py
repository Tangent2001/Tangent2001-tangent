from get_data.get_comments import get_comment_data
from get_data.get_passage import get_passage_data


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    # get_data_sections('20200419', '20200630')
    get_passage_data('20200120', '20200630')
    get_comment_data('20200120', '20200630')
