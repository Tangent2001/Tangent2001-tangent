from datetime import datetime
import pandas as pd


def date_list(begin_date, end_date):
    # beginDate, endDate是形如‘20160601’的字符串或datetime格式
    date_l = [datetime.strftime(x, '%m%d') for x in list(pd.date_range(start=begin_date, end=end_date))]
    return date_l
