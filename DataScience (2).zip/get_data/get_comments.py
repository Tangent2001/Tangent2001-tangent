import requests
import pandas as pd
from get_data.get_links import get_news_links
import json
from bs4 import BeautifulSoup
from retrying import retry
from get_data.date_generator import date_list


# 网络不稳定时可用以下方法
def get_data_sections(start, end):
    date = date_list(start, end)
    all_comments = []
    startDate = start[-4:]
    dateCount = 0
    for i in date:
        if dateCount == 0:
            startDate = i
        dateCount += 1
        links = get_news_links(i)
        comments = get_one_day_comment(links)
        if comments is not None:
            all_comments.extend(comments)
        print('Date ' + i + ' collected')
        # 此处可设置每个.xlsx文件中包含的新闻所跨的天数
        if dateCount == 30 or i == end[-4:]:
            dataFrame = pd.DataFrame(all_comments)
            # 要提前创建好文件夹
            dataFrame.to_excel('D:\\DataScience\\Part5\\' + startDate + '-' + i + '.xlsx')
            print('Generated D:\\DataScience\\Part5\\' + startDate + '-' + i + '.xlsx')
            dateCount = 0
            all_comments = []


# 网络稳定时可用以下方法
def get_comment_data(start, end):
    date = date_list(start, end)
    all_comments = []
    for i in date:
        links = get_news_links(i)
        comments = get_one_day_comment(links)
        if comments is not None:
            all_comments.extend(comments)
        print('Date ' + i + ' comments collected')
    dataFrame = pd.DataFrame(all_comments)
    # 要提前创建好文件夹
    dataFrame.to_excel('D:\\DataScience\\Part5\\comments.xlsx')
    print('Generated D:\\DataScience\\Part5\\comments.xlsx')


def get_one_day_comment(news_links):
    one_day_comment = []
    for link in news_links:
        one_news_comment = get_one_news_comments(link)
        if one_news_comment is not None:
            one_day_comment.extend(one_news_comment)
    return one_day_comment


@retry(stop_max_attempt_number=5, wait_fixed=3000)
def get_one_news_comments(link):
    one_news_comments = []
    req = requests.get(link)
    if req.status_code != 200:
        return None
    news_soup = BeautifulSoup(req.text, 'lxml')
    title = news_soup.find('h1').string
    # 被封的文章
    if title is None:
        return None
    newsID = link[link.rfind('/') + 1:-5]
    # 可调整爬取的数据数量
    comment_site = requests.get('https://comment.api.163.com/api/v1/products/a2869674571f77b5a0867c3d71db5856'
                                '/threads/' + newsID + '/comments/hotList?limit=20', timeout=3)
    comments_dict = json.loads(comment_site.text)
    if 'comments' in comments_dict:
        comments = comments_dict['comments']
        for k in comments.keys():
            c = comments[k]
            comment = {'标题': title,
                       '评论内容': c['content'],
                       '发布时间': c['createTime'],
                       '点赞数': c['vote'],
                       '地区': c['user']['location']}
            one_news_comments.append(comment)
    return one_news_comments
