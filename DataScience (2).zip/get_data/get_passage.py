import requests
import pandas as pd
from get_data.get_links import get_news_links
from bs4 import BeautifulSoup
from retrying import retry
from get_data.date_generator import date_list


def get_passage_data(start, end):
    date = date_list(start, end)
    all_passages = []
    for i in date:
        links = get_news_links(i)
        passage = get_passage(links)
        if passage is not None:
            all_passages.extend(passage)
        print('Date ' + i + ' passages collected')
    dataFrame = pd.DataFrame(all_passages)
    # 要提前创建好文件夹
    dataFrame.to_excel('D:\\DataScience\\Part5\\passage.xlsx')
    print('Generated D:\\DataScience\\Part5\\passage.xlsx')


def get_passage(links):
    passages = []
    for l in links:
        passage = get_one_passage(l)
        if passage is not None:
            passages.append(passage)
    return passages


@retry(stop_max_attempt_number=5, wait_fixed=3000)
def get_one_passage(link):
    news_soup = BeautifulSoup(requests.get(link, timeout=3).text, 'lxml')
    title = news_soup.find('h1').string
    # 被封的文章
    if title is None:
        return None
    passage_soup = news_soup.find('div', attrs={'class': 'post_body'})
    return {'标题': title, '内容': passage_soup.text}
