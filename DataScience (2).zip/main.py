from separate_words.separate import separate
from snownlp_analyze.snownlp_analyze import predict,train
from word_count.word_count import word_count, emoji_count
from keras_analyze.keras_analyze import analyze

if __name__ == '__main__':
    # separate(r'D:\DataScience\final\all_comment.xlsx', r'D:\DataScience\final\separate.xlsx')
    # train()
    # predict(r'D:\DataScience\final\separate.xlsx', r'D:\DataScience\final\sentiment.xlsx')
    # word_count(r'D:\DataScience\final\0123-0207.xlsx', r'D:\DataScience\final\0123-0207count.xlsx')
    # emoji_count(r'D:\DataScience\final\separate.xlsx', r'D:\DataScience\final\emoji_count.xlsx')
    analyze()