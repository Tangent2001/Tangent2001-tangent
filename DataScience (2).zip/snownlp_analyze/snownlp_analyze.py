from snownlp import sentiment, SnowNLP
import pandas as pd


def train():
    sentiment.train(r'D:\Anaconda3\Lib\site-packages\snownlp\sentiment\neg.txt',
                    r'D:\Anaconda3\Lib\site-packages\snownlp\sentiment\pos.txt')
    sentiment.save(r'D:\Anaconda3\Lib\site-packages\snownlp\sentiment\sentiment.marshal')


def predict(in_file, out_file):
    xlsx = pd.read_excel(in_file)
    comments = xlsx['评论内容']
    sen = []
    for c in comments:
        c = str(c)
        s = SnowNLP(c).sentiments
        sen.append(s)
    xlsx.insert(len(xlsx.columns), '情感得分', sen)
    xlsx.to_excel(out_file)
    print('Generated ' + out_file)

