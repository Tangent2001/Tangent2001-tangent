from pyecharts import options as opts
from pyecharts.charts import Map
from pyecharts.faker import Faker
import xlrd
import numpy as np
from matplotlib import pyplot as plt
#打开excel
wb = xlrd.open_workbook('loc_calc.xlsx',encoding_override='utf-8')
#按工作簿定位工作表
sh = wb.sheet_by_name('Sheet1')

x = sh.col_values(0)
y = sh.col_values(1)
pieces = [

    {"max":410,'min':210,'label':'>210,心态良好','color':'#ffcccc'},
    {"max":209,'min':9,'label':'9-209,心态积极且一般','color':'#ccffff'},
    {"max":8,'min':-192,'label':'-192-8,心态消极且一般','color':'#99ffff'},
    {"max":-193,'min':-393,'label':'-393--193,心态差劲','color':'#66ffff'},
    {"max":-394,'min':-594,'label':'-594--394,心态糟糕','color':'#33ffff'},
    {"max":-595,'min':-2000,'label':'<-595,心态奔溃','color':'#00ccff'},
]
def draw(pieces):
    c = (
        Map(init_opts=opts.InitOpts(width='1000px',height='880px'))
            .add("民众情绪得分", [list(z) for z in zip(x[1:],y[1:])], "china")
            .set_global_opts(
            title_opts=opts.TitleOpts(title="中国民众情绪地图分布"),
            visualmap_opts=opts.VisualMapOpts(max_=200,is_piecewise=True,pieces=pieces),
        )
            .render("民众心态地图.html")
    )
draw(pieces)
