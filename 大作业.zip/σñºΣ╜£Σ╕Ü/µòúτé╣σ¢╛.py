import xlrd
import numpy as np
from matplotlib import pyplot as plt
#打开excel
wb = xlrd.open_workbook('calc.xlsx',encoding_override='utf-8')
#按工作簿定位工作表
sh = wb.sheet_by_name('Sheet1')

x = sh.col_values(0)
y = sh.col_values(1)
plt.scatter(x[1:],y[1:],c=y[1:],s = 5.0)
plt.show()

