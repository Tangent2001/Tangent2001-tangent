import random
import datetime

import pyecharts.options as opts
from pyecharts.charts import Calendar

import xlrd
import numpy as np
from matplotlib import pyplot as plt
#打开excel
wb = xlrd.open_workbook('calc.xlsx',encoding_override='utf-8')
#按工作簿定位工作表
sh = wb.sheet_by_name('Sheet1')
y = sh.col_values(1)
begin = datetime.date(2020, 1, 19)
end = datetime.date(2020, 7, 4)
data = [
    [str(begin +datetime.timedelta(days=i)),y[i]]
    for i in range((end-begin).days + 1)
]
pieces = [

    {"max":7025,'min':3953,'label':'>3953,心态良好','color':'#b4a7d6'},
    {"max":3953,'min':881,'label':'881-3953,心态积极','color':'#ee5151'},
    {"max":881,'min':0,'label':'0-881,心态一般','color':'#ffcccc'},
    {"max":0,'min':-2191,'label':'0--2191,心态差劲','color':'#ccffff'},
    {"max":-2191,'min':-5263,'label':'-5263--2191,心态糟糕','color':'#a3e587'},
    {"max":-5263,'min':-8335,'label':'-8335--5263,心态奔溃','color':'#783f04'},
]

(
    Calendar(init_opts=opts.InitOpts(width="1000px", height="1000px"))
    .add(
        series_name="",
        yaxis_data=data,
        calendar_opts=opts.CalendarOpts(
            pos_top="120",
            pos_left="30",
            pos_right="30",
            range_=['2020-01-19','2020-7-4'],
            daylabel_opts=opts.CalendarDayLabelOpts(name_map="cn"),
            monthlabel_opts=opts.CalendarMonthLabelOpts(name_map='cn'),
            yearlabel_opts=opts.CalendarYearLabelOpts(is_show=False),
        ),
    )
    .set_global_opts(
        title_opts=opts.TitleOpts(pos_top="30", pos_left="center", title="2020.1.19-7.4民众心态日历图"),
        visualmap_opts=opts.VisualMapOpts(
            max_=7025, min_=-8335, orient="horizontal", is_piecewise=True,pos_top="400px",pos_left="100px",pieces=pieces,
        ),
    )
    .render("calendar_heatmap.html")
)