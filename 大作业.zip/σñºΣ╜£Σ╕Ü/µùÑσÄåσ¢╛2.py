import random
import datetime

import pyecharts.options as opts
from pyecharts.charts import Calendar

import xlrd
import numpy as np
from matplotlib import pyplot as plt
#打开excel
wb = xlrd.open_workbook('关注度.xlsx',encoding_override='utf-8')
#按工作簿定位工作表
sh = wb.sheet_by_name('Sheet1')
y = sh.col_values(1)
begin = datetime.date(2020, 1, 19)
end = datetime.date(2020, 7, 4)
data = [
    [str(begin +datetime.timedelta(days=i)),y[i]]
    for i in range((end-begin).days + 1)
]

(
    Calendar(init_opts=opts.InitOpts(width="1000px", height="1000px"))
    .add(
        series_name="",
        yaxis_data=data,
        calendar_opts=opts.CalendarOpts(
            pos_top="120",
            pos_left="30",
            pos_right="30",
            range_=['2020-01-19','2020-7-4'],
            daylabel_opts=opts.CalendarDayLabelOpts(name_map="cn"),
            monthlabel_opts=opts.CalendarMonthLabelOpts(name_map='cn'),
            yearlabel_opts=opts.CalendarYearLabelOpts(is_show=False),
        ),
    )
    .set_global_opts(
        title_opts=opts.TitleOpts(pos_top="30", pos_left="center", title="2020.1.19-7.4民众疫情关注度日历图"),
        visualmap_opts=opts.VisualMapOpts(
            max_=4226, min_=9, orient="horizontal", is_piecewise=False,pos_top="400px",pos_left="100px",
        ),
    )
    .render("民众疫情关注度日历图.html")
)
