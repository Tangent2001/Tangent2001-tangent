from count.countScore import sentiment_analyze

if __name__ == '__main__':
    # sentiment_analyze(r'D:\DataScience\weibo_separate2.xlsx')
    sentiment_analyze(r'D:\DataScience\netease_separate4.xlsx',r'D:\DataScience\sentiment1.xlsx')